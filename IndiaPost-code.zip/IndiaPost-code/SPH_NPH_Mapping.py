import csv
from datetime import datetime, timedelta
import openpyxl
import time
import math
import os
import pandas as pd

fp_out = openpyxl.Workbook()
sheet_out = fp_out.active

fp_tp = openpyxl.load_workbook('SPH-NPH Mapping.xlsx')
sheet_tp = fp_tp.get_sheet_by_name('SPH')
num_rows_tp = sheet_tp.max_row -1

fp_tp2 = openpyxl.load_workbook('SPH-NPH Mapping.xlsx')
sheet_tp2 = fp_tp2.get_sheet_by_name('NPH')
num_rows_tp2 = sheet_tp2.max_row -1

print(str(sheet_tp.cell(row = 2, column = 1).value))
print(str(sheet_tp2.cell(row = 2, column = 1).value))
TP_list= [[] for x in range((num_rows_tp*num_rows_tp2)+1)]
for i in range(num_rows_tp):
	for j in range(num_rows_tp2):
		src = str(sheet_tp.cell(row = i+2, column = 1).value)
		dest = str(sheet_tp2.cell(row =j+2, column = 1).value)
		print(src,dest)
		a = (num_rows_tp*i)+j 
		print(a)
		sheet_out.cell(row = a+1 , column = 1).value = src
		sheet_out.cell(row = a+1, column = 2).value = dest

fp_out.save('SPH_NPH.xlsx')

