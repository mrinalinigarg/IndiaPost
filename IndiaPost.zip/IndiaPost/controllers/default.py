import os
import shutil
import gluon
#import Test
#from requests import get
#from csv import DictReader
#from bs4 import BeautifulSoup as Soup
#from io import StringIO
#import pandas
import subprocess
#import datetime
#import urllib2
#from datetime import timedelta
# -*- coding: utf-8 -*-
# this file is released under public domain and you can use without limitations

# -------------------------------------------------------------------------
# This is a sample controller
# - index is the default action of any application
# - user is required for authentication and authorization
# - download is for downloading files uploaded in the db (does streaming)
# -------------------------------------------------------------------------



def index():
    """
    example action using the internationalization operator T and flash
    rendered by views/default/index.html or views/generic.html

    if you need a simple wiki simply replace the two lines below with:
    return auth.wiki()
    """

    response.menu.append((T('Udate'), False, URL('default', 'update'), []))
#    response.menu.append((T('Reports'), False, URL('default', 'reports'), []))
    #response.menu.append((T('Stats'), False, URL('default', 'stats'), []))
#    response.menu.append((T('System'), False, URL('default', 'system'), []))
    #response.menu.append((T('Contact Us'), False, URL('default', 'connect'), []))
    #fileNames = ['Client_Data_1', 'Client_Data_2', 'Client_Data_3', 'Client_Data_4', 'Client_Data_5']
    ModeNames = ['Air', 'Surface']
    TransitType = ['NPH to NPH', 'NPH to SPH','SPH to NPH','SPH to SPH']
    uploadStatus = ""
    #uploadStatus1 = ""
    block=""
    unirep=""
    nnsrep =""
    uploadForm  = FORM(
        H2(B("India Post Application!")),BR(),
        P(STRONG("Code Execution Screen"), _style='font-size:17px;'),
        HR(),
        DIV("Select Mode of Travel:", BR(), SELECT([OPTION(i, _value=str(i)) for i in ModeNames],  BR(), _class="form-control", _name='fileSelect1',_align="center", _value='Select a file'), BR(), _class ="col-md-6", _style="font-size:16px;"),
       DIV("Select Transit Type:", BR(), SELECT([OPTION(i, _value=str(i)) for i in TransitType],  BR(), _class="form-control", _name='fileSelect2',_align="center", _value='Select a file'), BR(), _class ="col-md-6", _style="font-size:16px;"),
        #DIV("Select Date:", BR(), INPUT(_type='date', _value='Select a Date', _class="form-control", _name='daySelect', _align="center"), BR(), _class ="col-md-6", _style="font-size:16px;"),
        #DIV("Select Time:", BR(), INPUT(_type='time', _value='12:00', _class="form-control", _name='apt_time', _align="center"), BR(), _class ="col-md-6", _style="font-size:18px;"),
        HR(),
        LABEL("* ", "Upload Input Excel file ", " *", BR(), INPUT(_type='file', _name="UploadFileName", requires=IS_NOT_EMPTY()), _class='btn btn-primary btn-lg btn-file', _style='font-size:17px; background-color:#33446e;'),
        HR(),
        INPUT(_type='submit', _value='Upload data to Database', _class='btn btn-warning', _style="background-color:#33446e;font-size:14px;"),
        #HR(),
        #INPUT(_type='file', _value='Download Output', _class='btn btn-warning', _style="background-color:#33446e;font-size:14px;"),
        HR()

 )
    Mode_of_Travel =(str(request.vars.fileSelect1))
    Transit_type =(str(request.vars.fileSelect2))
    scrapers_path =""

    if uploadForm.process(formname='af').accepted:
    	uploadStatus="Form is being validated."
        
        filename = str(request.vars.fileSelect1) + "_" + str(request.vars.fileSelect2) + ".xlsx"
        print(filename)

        upload_folder_temp = "C:\\web2py_win\\web2py\\applications\\IndiaPost\\Source Code\\IndiaPost\\"
        file = request.vars.UploadFileName.file
        path = upload_folder_temp +"\\" + filename
        print(file)

        if not(os.path.exists(upload_folder_temp)):
            os.makedirs(upload_folder_temp)
            uploadStatus="New folder is created."

        shutil.copyfileobj(file, open(path,'wb'))
        #reqUri = "http://10.0.1.4:2134/services/uploadHandle.php?notifDate="+str(request.vars.daySelect)+"&fileName="+ str(request.vars.fileSelect)
        #reqUri = urllib2.Request("http://10.0.1.4:2134/services/uploadHandle.php?notifDate=2018-04-04&fileName=TA")
        #defResp = urllib2.urlopen("http://10.0.1.4:2134/services/uploadHandle.php?notifDate=2018-04-04&fileName=TA").read()
        #uploadStatus = "Thanks! Your file was successfully uploaded for date:"+ "<strong>" +"15 June 2018" +  "</strong>!"
        python_path= "C:\\Users\\mrinalini1\\AppData\\Local\\Programs\\Python\\Python36\\python.exe"
        if(Mode_of_Travel=='Surface') and (Transit_type == 'NPH to NPH'):
        	scrapers_path = "C:\\web2py_win\\web2py\\applications\\IndiaPost\\Source Code\\IndiaPost\\opt_transit_NPH_NPH_Surface.py"
        	valid_path = "C:\\web2py_win\\web2py\\applications\\IndiaPost\\Source Code\\IndiaPost\\Validation_NPH_NPH_Surface.py"
        	bl=subprocess.check_output([ python_path, valid_path, "-block"])
        	block = bl.decode("ascii")
        	#block = bl.decode("ascii").split()
        	print(block)
        	uploadStatus = block
        	#subprocess.Popen([python_path,valid_path], stdout=subprocess.PIPE)
			#out = valid.communicate()
        	#subprocess.getstatusoutput('C:\\web2py_win\\web2py\\applications\\IndiaPost\\Source Code\\IndiaPost\\Surface_NPH to NPH.xlsx')
			#print(out)
        elif(Mode_of_Travel=='Air') and (Transit_type == 'NPH to NPH'):
        	scrapers_path="C:\\web2py_win\\web2py\\applications\\IndiaPost\\Source Code\\IndiaPost\\opt_transit_NPH_NPH_Air.py"
        	valid_path = "C:\\web2py_win\\web2py\\applications\\IndiaPost\\Source Code\\IndiaPost\\Validation_NPH_NPH_Air.py"
        	bl=subprocess.check_output([ python_path, valid_path, "-block"])
        	block = bl.decode("ascii")
        	#block = bl.decode("ascii").split()
        	print(block)
        	uploadStatus = block
        elif(Mode_of_Travel=='Air') and (Transit_type == 'NPH to SPH'):
        	scrapers_path="C:\\web2py_win\\web2py\\applications\\IndiaPost\\Source Code\\IndiaPost\\opt_transit_NPH_SPH_Air.py"
        	valid_path = "C:\\web2py_win\\web2py\\applications\\IndiaPost\\Source Code\\IndiaPost\\Validation_NPH_SPH_Air.py"
        	bl=subprocess.check_output([ python_path, valid_path, "-block"])
        	block = bl.decode("ascii")
        	#block = bl.decode("ascii").split()
        	print(block)
        	uploadStatus = block
        elif(Mode_of_Travel=='Surface') and (Transit_type == 'NPH to SPH'):
        	scrapers_path="C:\\web2py_win\\web2py\\applications\\IndiaPost\\Source Code\\IndiaPost\\opt_transit_NPH_SPH_Surface.py"
        	valid_path = "C:\\web2py_win\\web2py\\applications\\IndiaPost\\Source Code\\IndiaPost\\Validation_NPH_SPH_Surface.py"
        	bl=subprocess.check_output([ python_path, valid_path, "-block"])
        	block = bl.decode("ascii")
        	#block = bl.decode("ascii").split()
        	print(block)
        	uploadStatus = block
        elif(Mode_of_Travel=='Air') and (Transit_type == 'SPH to NPH'):
        	scrapers_path="C:\\web2py_win\\web2py\\applications\\IndiaPost\\Source Code\\IndiaPost\\opt_transit_SPH_NPH_Air.py"
        	valid_path = "C:\\web2py_win\\web2py\\applications\\IndiaPost\\Source Code\\IndiaPost\\Validation_SPH_NPH_Air.py"
        	bl=subprocess.check_output([ python_path, valid_path, "-block"])
        	block = bl.decode("ascii")
        	#block = bl.decode("ascii").split()
        	print(block)
        	uploadStatus = block
        elif(Mode_of_Travel=='Surface') and (Transit_type == 'SPH to NPH'):
        	scrapers_path="C:\\web2py_win\\web2py\\applications\\IndiaPost\\Source Code\\IndiaPost\\opt_transit_SPH_NPH_Surface.py"
        	valid_path = "C:\\web2py_win\\web2py\\applications\\IndiaPost\\Source Code\\IndiaPost\\Validation_SPH_NPH_Surface.py"
        	bl=subprocess.check_output([ python_path, valid_path, "-block"])
        	block = bl.decode("ascii")
        	#block = bl.decode("ascii").split()
        	print(block)
        	uploadStatus = block
        elif(Mode_of_Travel=='Air') and (Transit_type == 'SPH to SPH'):
        	scrapers_path="C:\\web2py_win\\web2py\\applications\\IndiaPost\\Source Code\\IndiaPost\\opt_transit_SPH_SPH_Air.py"
        	valid_path = "C:\\web2py_win\\web2py\\applications\\IndiaPost\\Source Code\\IndiaPost\\Validation_SPH_SPH_Air.py"
        	bl=subprocess.check_output([ python_path, valid_path, "-block"])
        	block = bl.decode("ascii")
        	#block = bl.decode("ascii").split()
        	print(block)
        	uploadStatus = block
        elif(Mode_of_Travel=='Surface') and (Transit_type == 'SPH to SPH'):
        	#print(Mode_of_Travel,Transit_type)
        	scrapers_path="C:\\web2py_win\\web2py\\applications\\IndiaPost\\Source Code\\IndiaPost\\opt_transit_SPH_SPH_Surface.py"
        	valid_path = "C:\\web2py_win\\web2py\\applications\\IndiaPost\\Source Code\\IndiaPost\\Validation_SPH_SPH_Surface.py"
        	bl=subprocess.check_output([ python_path, valid_path, "-block"])
        	block = bl.decode("ascii")
        	#block = bl.decode("ascii").split()
        	print(block)
        	uploadStatus = block

    
        subprocess.check_output([python_path,scrapers_path])
        shutil.copyfile("C:\\web2py_win\\web2py\\applications\\IndiaPost\\private\\Output.xlsx","C:\\web2py_win\\web2py\\applications\\IndiaPost\\static\\Download_outputs\\Output.xlsx")
        print(block[0])
        if(block[0]=='F'):
        	uploadStatus=("Code Execution Complete. You may download the output file")
        else:
        	pass

    unirep = URL("IndiaPost", "static", "Download_formats\\Input_Format.xlsx") 
    nnsrep = URL("IndiaPost", "static", "Download_outputs\\Output.xlsx") 
    #nnsrep = URL("IndiaPost", "private", "Outputs\\NPH_NPH_Surface.xlsx")
    #print(nnsrep) 
        #execfile(
        #gluon.shell.env("IndiaPost", import_models=True, c="default.py", f="index", dir="", extra_request={})
        #gluon.shell.exec_environment(pyfile=scrapers_path,request = None,response= None, session = None)
        #os.system(scrapers_path)
        # with open ("C:\\Users\\mrinalini1\\Documents\\helloINDIA.txt", "w") as f:
	    #     f.write("Hello world")
        # print("ABC")

    #return dict(uploadForm=uploadForm)
    return locals()

def update():
     return dict()


def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/bulk_register
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    also notice there is http://..../[app]/appadmin/manage/auth to allow administrator to manage users
    """
    return dict(form=auth())


#@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service()
