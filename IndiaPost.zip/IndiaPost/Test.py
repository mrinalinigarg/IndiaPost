# -*- coding: utf-8 -*-
with open ("C:\\web2py_win\\web2py\\applications\\IndiaPost\\private\\HelloInDIaPosT.txt", "w") as f:
	f.write("Hello world")
print("GHI")
